// Question No 1
for (var i = 0; i <= 4; i++) {
    console.log("Hello World");
};

// Question No 2
for (var i = 1; i <= 10; i++) {
    console.log(i);
};


// Question No 3
var userNum = prompt("Enter a number to print multiplication table");
var userLength = prompt("Enter length of multiplication table");
for (var i = 1; i <= userLength; i++) {
    console.log(userNum + ' x ' + i + ' = ' + userNum * i);
};



// Question No 4
var mobiles = ['Nokia', 'Samsung', 'Apple', 'Sony', 'Huawei'];
for (var i = 0; i <= mobiles.length; i++) {
    console.log(mobiles[i]);
};


// Question No 5
var fruits = ["Mango", "Apple", "Banana", "Orange", "Strawberry"];
for (var i = 0; i < fruits.length; i++) {
    console.log(fruits[i]);
    console.log("Element at index " + i + " is " + fruits[i]);
};


// Question No 6

// Question No 7
for (var i = 1; i <= 15; i++) {
    console.log('Counting: ' + i);
};

for(var i = 0; i < 10; i++) {
    console.log('Reverse Counting: ' + i);
}


// Question No 8
var bakery = ["cake", "apple pie", "cookie", "chips", "patties"];
var userInput = prompt('Enter your favorite bakery item');
for (var i = 0; i <= bakery.length; i++) {
    if (userInput === bakery[i]) {
        console.log(bakery[i] + " : Founded")
    }
    else {
        console.log(bakery[i] + " : Not found")
    }
}


// Question No 9
var num = [24, 53, 78, 91, 12];
var largeNumber = num[0];
for (var i = 0; i < num.length; i++) {
    if (num[i] > largeNumber) {
        largeNumber = num[i]
    }
}
console.log(largeNumber)


// Question No 10
var num = [24, 53, 78, 91, 12];
var smallerNumber = num[0];
for (var i = 0; i < num.length; i++) {
    if (num[i] < smallerNumber) {
        smallerNumber = num[i]
    }
}
console.log(smallerNumber);


// Question No 11
var nums = [24, 53, 78, 91, 12]
var smallestNum = nums[0]
var largestNum = nums[0]

for(var i = 0; i < nums.length; i++) {
    if(nums[i] < smallestNum){
        smallestNum = nums[i]
    } else if (nums[i] > largestNum) {
        largestNum = nums[i]
    }
}  
console.log('The largest number is ' + largestNum)
console.log('The smallest number is ' + smallestNum)

// Question No 12
for (var i = 1; i <= 100; i++) {
    if (i % 5 === 0) {
      console.log(i);
    }
  }  

  
// Question No 13
var students = ["Ali", "Taha", "Bilal", "Arsalan"];
var scores = [58, 73, 89, 90];
for (var i = 0; i <= students.length && i <= scores.length; i++) {
    console.log('Student ' + 'Scores');
    console.log(students[i] + ' ' + scores[i]);
}


// Question No 14

// Question No 15
var multipleArray = [ [1,2,3] , [4,5,6] , [7,8,9] ];
for (var i = 0; i <= multipleArray.length; i++) {
    console.log(multipleArray[i])
}


// Question No 16
var userNumber = prompt('Enter a number');
for (var i = userNumber; i >= 0; i-=0.5) {
    console.log(i);
}


// Question No 17
for (var i = 0; i <= 20; i++) {
    if (i%2) {
        console.log(i +' is Odd')
    }
    else {
        console.log(i +' is Even')
    }
}

// Question No 18

// Question No 19

// Question No 20
// a
for (var i = 0; i <= 4; i++) {
    console.log("*****");
};